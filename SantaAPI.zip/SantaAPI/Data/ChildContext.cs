﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SantaAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SantaAPI.Data
{
    public class ChildContext : IdentityDbContext<IdentityUser>
    {
        public ChildContext(DbContextOptions<ChildContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            #region "Seed Data"

            builder.Entity<IdentityRole>().HasData(
                new { Id = "1", Name = "Admin", NormalizedName = "ADMIN" },
                new { Id = "2", Name = "Child", NormalizedName = "CHILD" }
            );

            #endregion
        }

        public DbSet<Child> Children { get; set; }
        /*
        public override int SaveChanges()
        {
            UpdateTimeAndUser();
            return base.SaveChanges();
        }

        private void UpdateTimeAndUser()
        {
            var entities = ChangeTracker.Entries().Where(x => x.Entity is Child && (x.State == EntityState.Added || x.State == EntityState.Modified));
            
            var currentUsername = !string.IsNullOrEmpty(Ge())
                ? HttpContext.Current.User.Identity.Name
                : "Anonymous";

            foreach (var entity in entities)
            {
                if (entity.State == EntityState.Added)
                {
                    ((Child)entity.Entity).DateCreated = DateTime.UtcNow;
                    ((Child)entity.Entity).CreatedBy = currentUsername;
                }
            }
        }*/
    }
}
